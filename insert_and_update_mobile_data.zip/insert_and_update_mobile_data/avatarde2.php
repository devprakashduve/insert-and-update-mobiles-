<?php


$con=mysqli_connect("localhost","root","","avatarde");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  else{
  //  echo "connected";
  }
/*// Turn off error reporting
error_reporting(0);

// Report runtime errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Report all errors
error_reporting(E_ALL);

// Same as error_reporting(E_ALL);
ini_set("error_reporting", E_ALL);

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE); 
*/

function curl($url, $post='',$con,$id){
        //cURL options
        $options = array(

            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 500,      // timeout on connect
            CURLOPT_TIMEOUT        => 500,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_USERAGENT      => "",
            CURLOPT_COOKIESESSION  => false,
        );

        //Go go go!
        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );

        $output['content'] = curl_exec( $ch );
       /* $output['err']     = curl_errno( $ch );
        $output['errmsg']  = curl_error( $ch );
        $output['header']  = curl_getinfo( $ch );*/
        //var_dump($output);
                    //}

$doc = new DOMDocument;
        @$doc->loadHTML($output['content']);
        $doc->preserveWhiteSpace = false;

        $xpath = new DOMXpath($doc);       

        $nodeList = $xpath->query("//aside[@class='col-sm-12 col-lg-7']");        

        $model_name=[];
$model_price=[];


        foreach($nodeList as $node){
           $description=$node->textContent;
           echo "<br>";
           $mobile_name=str_replace('NewsReviewsPhotosVideos','',$description);
           //echo $mobile_name;
           array_push($model_name,$mobile_name);
           //var_dump($description);
}
$nodeList = $xpath->query("//aside[@class='read-exp col-sm-12 col-lg-3']");        
        foreach($nodeList as $node){
           $description=$node->textContent;
           echo "<br>";
           $mobile_price=trim(str_replace('Add to Compare','',$description));
           $mobile_price=trim(str_replace('Buy Now','',$mobile_price));
           $mobile_price=trim(str_replace(',','',$mobile_price));
           //$mobile_price=str_replace('Price Not Available','',$mobile_price);
           if($mobile_price==="Price Not Available"){            
            $mobile_price='';
           }else{
            $mobile_price=$mobile_price;
           }
           //echo $mobile_price;
           array_push($model_price,$mobile_price);
         //  var_dump($description);
}

//$mobo_name=[];
for ($i=0; $i <11 ; $i++){ 
  echo $model_name[$i].'=>'.$model_price[$i].'<br>';
$mobo=explode('(',$model_name[$i]);
$mobo=trim($mobo[0]);
$sql2="SELECT name FROM mobile_models where brand_id=$id";
//echo $sql2;
if($result2=mysqli_query($con,$sql2))
  {
     while($row2=mysqli_fetch_assoc($result2)){
     $brand2=trim($row2['name']); 
     $brand2=str_replace('+',' ',$brand2);
     if (trim($mobo)==trim($brand2)) {
                    echo $mobo.'=>'.$model_price[$i].'<br>';
                    $price=$model_price[$i];

                    $sql = "UPDATE mobile_models SET `basic_price`='".$price."' WHERE name LIKE '%$mobo%'";

if (mysqli_query($con, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($con);
}   }              
    

     
     
}
}
}
        
//var_dump($model_name);
//var_dump($mobile_price);

return $output;

/*
                      $price.'<br>';
        $date.'<br>';    
        $releasedate.'<br>';*/
 

    }




if (isset($_REQUEST['id'])){
  $id=$_REQUEST['id'];
}else{$id=1;}
if(isset($_REQUEST['no'])) {
  $no=$_REQUEST['no'];
}else{$no=2;}

$sql="SELECT id,name FROM brands where id=$id";

if($result=mysqli_query($con,$sql))
  {
    if(mysqli_num_rows($result)>=1){
  
    while ($row=mysqli_fetch_assoc($result)) {
      
     $brand=strtolower(trim($row['name'])); 
         
     if($_REQUEST['no']==15){
        $no='';
        $id=$id+1;
      }
        else{
        $no=$_REQUEST['no']+1;
      }
}
$data=curl('www.bgr.in/gadgets/mobile-phones/'.$brand.'/page/'.$no.'#model','',$con,$id);
/*sleep(1);*/
//echo $brand.'/';
echo 'www.bgr.in/gadgets/mobile-phones/'.$brand.'/page/'.$no.'#model';
}
else{
    $id=$id+1;
  }
      


  //echo $no.'=>';

//  echo "<hr>";
  //var_dump($data);



  }
 
//print_r($data);
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body id="bdy">
<script>
//alert(next_city); 
var id="<?php echo $id;?>";
var no="<?php echo $no;?>";
if(id.length>=0 && no<=15 && id<=5000){
  setTimeout(function(){
  window.location.href = "http://localhost/moviepazes_pro/avatarde2.php?id="+id+"&no="+no;
},100);
}
</script>
</body>
</html>