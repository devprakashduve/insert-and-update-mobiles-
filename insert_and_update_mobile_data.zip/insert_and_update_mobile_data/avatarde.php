<?php

// Turn off error reporting
error_reporting(0);

// Report runtime errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Report all errors
error_reporting(E_ALL);

// Same as error_reporting(E_ALL);
ini_set("error_reporting", E_ALL);

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE); 


function curl($url, $post=''){
        //cURL options
        $options = array(

            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 500,      // timeout on connect
            CURLOPT_TIMEOUT        => 500,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_USERAGENT      => "",
            CURLOPT_COOKIESESSION  => false,
        );
        //Go go go!
        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );

        $output['content'] = curl_exec( $ch );
       /* $output['err']     = curl_errno( $ch );
        $output['errmsg']  = curl_error( $ch );
        $output['header']  = curl_getinfo( $ch );*/
        //var_dump($output);

        $doc = new DOMDocument;
        @$doc->loadHTML($output['content']);
        $doc->preserveWhiteSpace = false;
        $xpath = new DOMXpath($doc);
        $nodeList = $xpath->query("//h3[@class='fl']");
        $price='';
        foreach($nodeList as $node){
           $model_name=$node->textContent;
           echo "<h1>Brand Name</h1>";
           $var=explode(' ', trim($model_name));
           echo $var[0];
           $brand_name=$var[0];
           echo "<h1>Model Name</h1>";
           echo $model_name;
           //var_dump($node);
           }
        $nodeList = $xpath->query("//div[@class='content_text row margin_t10 margin_b30']");
        $price='';        
        $filterstr='';
        $j=0;
        foreach($nodeList as $node){
           $description=$node->textContent;
          // var_dump($description);
           $data=explode('phone comes ',$description);
           $description=str_replace($data[0],$model_name,$description);
           $data=explode('. ',$description);
            for($i=0;$i<=sizeof($data)-1;$i++){
            $Rval=$data[$i];
            if (strpos($Rval, 'price in')!== false) {
              /*echo 'yes'.$i.'<br>';
              echo 'yes'.$data[$i].'<br>';*/
              $j=$i+1;
              $data[$i]='';
              $data[$j]='';
            }else{
            $filterstr.=$Rval.'. ';
            }
           }
           $description=$filterstr;
           /*foreach ($data as  $value) {
             echo $value.'<br>  ';
             $condition =strcmp($value,' price in India ');
             echo $condition;
           }*/
           $data=explode(' comes',$description);
           $description=str_replace($data[0],$model_name,$description);
           //$description=str_replace(' price in India starts from',' price in India starts with',$description);
           echo "<h1>Description</h1>";
           $description=str_replace(' As far as the cameras are concerned, t',' T',$description);
           $description=str_replace(' shooter for selfies','',$description);
           $description=str_replace(' It measures',' '.$model_name.' dimension is',$description);
           $description=str_replace(' phone packs ',' '.$model_name.' have ',$description);
           $description=str_replace(' in India','',$description);
           $description=str_replace(' Sensors on the phone include',' '.$model_name.' provide sensors that all are,',$description);
           $description=str_replace(' The ',' ',$description);
           $description=str_replace('. .','. ',$description);
           echo $description;
           $final_description=$description;
           $data=explode('. ',$description);
           foreach ($data as  $value) 
           {
           //echo $value.'<br>  ';
           }
           }
        $nodeList = $xpath->query("//div[@class='pd_detail_wrp margin_b30']");
        
        $price='';
        $date='';    
        $releasedate='';
        $final_Release_date='';
        $final_form_factor='';
        $final_Dimensions_mm='';
        $final_Weight_g='';
        $final_Battery_capacity_mAh='';
        $final_Removable_battery='';
        $final_colors='';        
        $final_Touchscreen='';
        $final_Screen_size_inches='';
        $final_resolution='';
        $final_Pixels_per_inch_PPI='';
        $fonal_processor='';
        $final_Processor_brand='';
        $final_ram='';
        $final_Expandable_storage_up_to_GB='';
        $final_Expandable_storage='';
        $final_Internal_storage='';
        $final_Expandable_storage_type='';
        $final_Rear_camera='';
        $final_Flash='';
        $final_Front_camera='';
        $final_os='';
        $final_Skin='';
        $final_Wi_Fi='';
        $final_Wi_Fi_standards_supported='';
        $final_GPS='';
        $final_Bluetooth='';
        $final_NFC='';
        $final_Infrared='';
        $final_USB_OTG='';
        $final_FM='';
        $final_number_of_sim='';
        $final_Sim1_type='';
        $final_Sim2_type='';
        $final_GSM_CDMA1='';
        $final_GSM_CDMA2='';
        $final_3G1='';
        $final_3G2='';
        $final_Compass_Magnetometer='';
        $final_Proximity_Sensors='';
        $final_Accelerometer='';
        $final_Ambient_light_sensor='';
        $final_Gyroscope='';
        $final_Temperature_sensor='';
        // var_dump($nodeList[0]);
        /* foreach($nodeList as $node){ */        
        $description=$nodeList[0]->textContent;
        echo "<hr>";
        // echo sizeof($nodeList);
         echo $description;
        // print_r($node);
        // var_dump($node);
            $description2=explode(' ',trim($description));
            echo "<h1>".$description2[0]."</h1>";
            $data=str_replace($description2[0],'',$description);
            $newdata=preg_split('/(?=[A-Z])/',trim($data));

foreach ($newdata as $i=>$value) { 
             if($value=="Release date"){
              $j=$i+1;
              $date=$date=strtotime($newdata[$j]);
              $final_Release_date=date('d-m-Y',$date);
              echo "Release date=>".$final_Release_date."<br>";                
              } 
              if($value=="Form factor"){
              $j=$i+1;
              $final_form_factor=$newdata[$j];
              echo "Form factor=>".$final_form_factor."<br>";                
              }
              $dimensions=explode(')',$value); 
              if ($dimensions[0]=="Dimensions (mm") {
                 $final_Dimensions_mm=$dimensions[1];
              echo "Dimensions (mm)=>". $final_Dimensions_mm."<br>";
              }
              if ($dimensions[0]=="Ah") {
                $final_Battery_capacity_mAh=$dimensions[1];
              echo "Battery capacity=>".$final_Battery_capacity_mAh."<br>";
              }
              if ($dimensions[0]=="Weight (g") {
                $final_Weight_g=$dimensions[1];
              echo "Weight =>".$final_Weight_g."<br>";
              }
              if($value=="Removable battery"){
              $j=$i+1;
              $final_Removable_battery=$newdata[$j];
              echo "Removable battery=>".$final_Removable_battery."<br>";                
              }
              if($value=="Colours"){
              $colors='';
              do {
                $j=$i++;
              $colors.=$newdata[$j];
              //$j=$j++;
               } while ( $newdata[$j]!="S"); 
               $colors=str_replace('S','',$colors);
               $colors=str_replace('Colours','',$colors);
               $final_colors=$colors;
              echo "Colours=>".$final_colors."<br>";
              }
               if($value=="R value"){
              $j=$i+1;
              if ($newdata[$j]="N") {
                $SAR="NA";
              }else{
                $SAR=$newdata[$j];
              }
               $SAR_value=$SAR;
              echo "SAR value=>". $SAR_value."<br>"; 
              }
              }

            /*if(strpos($data,'Alternate names')>=1){
            $data=substr($data,26);
            }
            $date2=explode('Release date',$data);
            if(isset($date2[1])){
            $releasedate=$date2[1];            
            }else{$releasedate=$data;}
            $screen_type=explode('Form factor',$releasedate);           
            if(isset($screen_type[1])){
            $screen_type_f=$screen_type[1];
            $date=strtotime($screen_type[0]);
           // $final_Release_date=date('d-m-Y',$date);
            echo "Release date => ".$screen_type[0]."<br>";
            }else{
            $screen_type_f=$releasedate;}

            $lanch_date=explode('Dimensions (mm)',$screen_type_f);                       
            if(isset($lanch_date[1])){
            $lanch_date_f=$lanch_date[1];
          //  $final_form_factor=$lanch_date[0];
            echo 'Screen type => '.$lanch_date[0]."<br>";
            }else{$lanch_date_f=$screen_type_f;}

            $dimention=explode('Weight (g)',$lanch_date_f);            
            if (isset($dimention[1])){$dimention_for_f=$dimention[1];
               // $final_Dimensions_mm=$dimention[0];
              echo 'Dimension => '.$dimention[0]."<br>";}
              else{$dimention_for_f=$lanch_date_f;}

            $weight=explode('Battery capacity (mAh)',$dimention_for_f);            
            if (isset($weight[1])){$weight_for_f=$weight[1];
            //    $final_Weight_g=$weight[0];
            echo 'Weight in G => '.$weight[0].'<br>';}else{$weight_for_f=$dimention_for_f;}
            
            $battery_type=explode('Removable battery',$weight_for_f);
            if (isset($battery_type[1])){
            $battery_type_f=$battery_type[1];
            //$final_Battery_capacity_mAh=$battery_type[0];
             echo 'Battery capacity (mAh) => '.$battery_type[0].'<br>';}
             else{$battery_type_f=$weight_for_f;}
            
            $battery_capacity=explode('Colours',$battery_type_f);            
            if (isset($battery_capacity[1])) {
            $battery_capacity_f=$battery_capacity[1];
            //$final_Removable_battery=$battery_capacity[0];
            echo 'Removable_battery => '.$battery_capacity[0].'<br>';
            }else{
              $battery_capacity_f=$battery_type_f;
            }
            $color_name_data=explode('SAR value',$battery_capacity_f);
            //$final_colors=$color_name_data[0];
            echo 'Colors => '.$color_name_data[0].'<br>';
            echo 'SAR_value '.$color_name_data[1].'<br>';*/
           // $SAR_value=$color_name_data[0];

          /*for display*/
          echo "<h1>Display</h1>";

$data2=$nodeList[1]->textContent; 
$data2=str_replace('DISPLAY','',$data2);

$displaydata=preg_split('/(?=[A-Z])/',trim($data2));
//var_dump($displaydata);
foreach ($displaydata as $i=>$value) { 
  //echo $value.'<br>';
  $screen=explode(')',$value); 
  $Resolution=explode('ution',$value); 
              if ($screen[0]=='Screen size (inches') {
                $final_Screen_size_inches=$screen[1];
                echo "Screen size =>".$screen[1].'<br>';
              }
              if ($screen[0]=='I') {
                $final_Pixels_per_inch_PPI=$screen[1];
                echo "PPI =>".$screen[1].'<br>';
              }
              if ($Resolution[0]=='Resol') {
                $final_resolution=$Resolution[1];
                echo "Resolution =>".$Resolution[1].'<br>';
              }
             if($value=="Touchscreen"){
              $j=$i+1;              
              echo "Touchscreen=>".$displaydata[$j]."<br>";                
              $final_Touchscreen=$displaydata[$j];
              }
              

            }
            /*$date2=explode('Screen size (inches)',$nodeList[1]->textContent); 
            if(isset($date2[1])){
            $releasedate=$date2[1];            
            }else{$releasedate=$data;}

            $Screen_size=explode('Touchscreen',$releasedate); 
            if(isset($Screen_size[1])){
            $Screen_size_for_f=$Screen_size[1];
            $final_Screen_size_inches=$Screen_size[0];
            echo 'Screen size (inches) => '.$Screen_size[0]."<br>";
            }else{$Screen_size_for_f=$data;}
            
            $screen_type=explode('Resolution',$Screen_size_for_f);           
            if(isset($screen_type[1])){
            $screen_type_for_f=$screen_type[1];
            $final_Touchscreen=$screen_type[0];            
            echo 'Touchscreen => '.$screen_type[0]."<br>";            
            }else{$screen_type_for_f=$Screen_size_for_f;}

            $resulution=explode('Pixels per inch (PPI)',$screen_type_for_f);           
            if(isset($resulution[1])){
            $resulution_for_f=$resulution[1];
            $final_resolution=$resulution[0];
            //echo 'resolution => '.$resulution[0]."<br>";
            }else{$resulution_for_f=$screen_type_for_f;
            $final_resolution=$resulution_for_f;}
           echo  'resolution => '.$final_resolution.'<br>';
           
           if ($final_resolution!=$resulution_for_f){
           $final_Pixels_per_inch_PPI=$resulution_for_f;
           }
            echo 'Pixels per inch (PPI) => '.$final_Pixels_per_inch_PPI."<br>";*/




            /*For Hardeware */           
            echo "<h1>HARDWARE</h1><hr>";
            echo $nodeList[2]->textContent.'<br>';
            /*$data2=$nodeList[2]->textContent;
           $data2=str_replace('HARDWARE','',$data2);

$Hardware=preg_split('/(?=[A-Z])/',trim($data2));
//var_dump($displaydata);
foreach ($Hardware as $i=>$value) { 

  echo $value.'<br>';

  $processer=explode('essor',$value); 
  
              if ($processer[0]=='Proc' && $processer[1]!=' make') {
                //$final_Screen_size_inches=$screen[1];
                $j=$i+1;
                $k=$j+1;
                echo "processer =>".$processer[1].$Hardware[$j].$Hardware[$k].'<br>';
                 $fonal_processor=$processer[1].$Hardware[$j].$Hardware[$k];
              }
              if ($value=='A'){
                $h=$i-1;
                if ($Hardware[$h]=='R') {
                $j=$i+1;
                $k=$j+1;
                $l=$k+1;
                $m=str_replace('M','',$Hardware[$j]);                
                echo "RAM =>".$m.$Hardware[$k].$Hardware[$l].'<br>';
                 $final_ram=$m.$Hardware[$k].$Hardware[$l];
              }}            
              if ($value=='Processor make') {

              $processerbrand='';
               do{
              $j=$i++;
              $processerbrand.=$Hardware[$j];
              //$j=$j++;
               } while ( $Hardware[$j]!="R"); 
               $processerbrand=str_replace('Processor make','',$processerbrand);
               $processerbrand=str_replace('R','',$processerbrand);

                echo "processer Make=>".$processerbrand.'<br>';
                 $final_Processor_brand=$processerbrand;
              }
}*/
            $data=str_replace('HARDWARE','',$nodeList[2]->textContent);
            $processor_make=explode('essor',$data);            
            if(isset($processor_make[1])){
            $processor_make_for_f=$processor_make[1];
            $procesor=str_replace('Proc','',$processor_make[1]);
            $procesor=explode(' ',$procesor);
            $fonal_processor=$procesor[0];
            echo "processor => ".$fonal_processor."<br>";            
            }else{$processor_make_for_f=$data;}            
           
            $RAM=explode('RAM',$data);           
            if(isset($RAM[1])){
            $RAM_for_f=$RAM[1];

            $final_Processor_brand=explode("Processor make",$RAM[0]);
            $final_Processor_brand=$final_Processor_brand[1];
            echo 'Processor brand => '.$final_Processor_brand."<br>"; 
            }else{$RAM_for_f=$processor_make_for_f;}

           $resulution=explode('Internal storage',$RAM_for_f);           
            if(isset($resulution[1])){
            $resulution_for_f=$resulution[1];
            $final_ram=str_replace('make','',$resulution[0]);
            echo "RAM => ".$final_ram."<br>";
            }else{$resulution_for_f=$RAM_for_f;}
         //  var_dump($resulution);
           $upto=explode('Expandable storage up to (GB)',$resulution[1]);           
            if(isset($upto[0])){           
            $final_Expandable_storage_up_to_GB=$upto[1];
            echo "Expandable storage up to (GB) => ".$upto[1]."<br>";
            }

            $Expandable_storage=explode('Expandable storage',$resulution_for_f);           
            if(isset($Expandable_storage[1])){
            $Expandable_storage_for_f=$Expandable_storage[2];
            $final_Internal_storage=str_replace('make','',$Expandable_storage[0]);
            $final_Expandable_storage=$Expandable_storage[1];
            echo "Internal storage => ".$final_Internal_storage."<br>";
            echo "Expandable storage => ".$final_Expandable_storage."<br>";
            }else{$Expandable_storage_for_f=$resulution_for_f;}

          $Expandable_storage_type=explode('type',$Expandable_storage_for_f);           
            if(isset($Expandable_storage_type[1])){
            $Expandable_storage_type_for_f=$Expandable_storage_type[1];
            $final_Expandable_storage_type=$Expandable_storage_type[1];
            echo "Expandable storage type => ".$Expandable_storage_type[1]."<br>";
            }else{$resulution_for_f=$screen_type_for_f;}

             /*for camera*/
             echo "<h1>Camera</h1>";

            $camera=explode('Rear camera',$nodeList[3]->textContent); 
            if(isset($camera[1])){
            $camera_for_f=$camera[1];            
            }else{$camera_for_f=$data;}

            $Flash=explode('Flash',$camera_for_f); 
            if(isset($Flash[1])){
            $Flash_for_f=$Flash[1];
            $final_Rear_camera=$Flash[0];
            echo 'Rear camera => '.$Flash[0]."<br>";
            }else{$Flash_for_f=$camera_for_f;}
            
            $Front_camera=explode('Front camera',$Flash_for_f);           
            if(isset($Front_camera[1])){
            $Front_camera_for_f=$Front_camera[1];
            $final_Flash=$Front_camera[0];
            echo 'Flash => '.$Front_camera[0]."<br>";            
            }
            $final_Front_camera=$Front_camera_for_f;
            echo 'Front camera => '.$Front_camera_for_f."<br>";

             /*for OS*/

             if (isset($nodeList[6]->textContent)){
                   echo "<h1>Os</h1>";
             $os=str_replace('SOFTWARE ','',$nodeList[4]->textContent);

            $os=explode('Operating System',$os); 
            //var_dump($os);
            if(isset($os[1])){
            $os_for_f=$os[1];            
            }else{$os_for_f=$data;}           

            $skin=explode('Skin',$os_for_f); 
            if(isset($skin[0])){
            $skin_for_f=$skin[1];
            $final_os=$skin[0];
            echo 'OS => '.$skin[0].'<br>';            
            }
            $final_Skin=$skin_for_f;
            echo 'Skin => '.$skin_for_f.'<br>';


          
    /*for Connectivity*/
    echo "<h1>Connectivity</h1>";
    $connectivity=str_replace('CONNECTIVITY ','',$nodeList[5]->textContent);
   // var_dump( $connectivity);

            $wifi=explode('Wi-Fi standards supported',$connectivity); 
            if(isset($wifi[1])){
            $final_Wi_Fi=str_replace('Wi-Fi','',$wifi[0]);
            echo 'Wi-Fi => '.str_replace('Wi-Fi','',$wifi[0]).'<br>';
            $wifi_for_f=$wifi[1];            
            }else{$wifi_for_f=$data;}           

            $gps=explode('GPS',$wifi_for_f); 
            if(isset($gps[1])){
            $gps_for_f=$gps[1];
            $final_Wi_Fi_standards_supported=$gps[0];
            echo 'Wi-Fi standards supported => '.$gps[0].'<br>';            
            }else{$gps_for_f=$wifi_for_f;}

            $Bluetooth=explode('Bluetooth',$gps_for_f); 
            if(isset($Bluetooth[1])){
            $Bluetooth_for_f=$Bluetooth[1];
            $final_GPS=$Bluetooth[0];
            echo 'GPS => '.$Bluetooth[0].'<br>';            
            }else{$Bluetooth_for_f=$gps_for_f;}            
            $NFC=explode('NFC',$Bluetooth_for_f); 
            if(isset($NFC[1])){
            $NFC_for_f=$NFC[1];
            $final_Bluetooth=$NFC[0];
            echo 'Bluetooth => '.$NFC[0].'<br>';            
            }else{$NFC_for_f=$Bluetooth_for_f;}
            $Infrared=explode('Infrared',$NFC_for_f); 
            if(isset($Infrared[1])){
            $Infrared_for_f=$Infrared[1];
            $final_NFC=$Infrared[0];
            echo 'NFC => '.$Infrared[0].'<br>';            
            }else{$Infrared_for_f=$NFC_for_f;}
            $USB_OTG=explode('USB OTG',$Infrared_for_f); 
            if(isset($USB_OTG[1])){
            $USB_OTG_for_f=$USB_OTG[1];
            $final_Infrared=$USB_OTG[0];
            echo 'Infrared => '.$USB_OTG[0].'<br>';
            }else{$USB_OTG_for_f=$Infrared_for_f;}
            $fm=explode('FM',$USB_OTG_for_f);
            if(isset($fm[1])){
            $fm_for_f=$fm[1];
            $final_USB_OTG=$fm[0];
            $final_USB_OTG_dummy=explode('Headphones',$final_USB_OTG);
            //var_dump($final_USB_OTG);
            $final_USB_OTG=$final_USB_OTG_dummy[0];
            $final_headphone=$final_USB_OTG_dummy[1];


            echo 'USB OTG => '.$final_USB_OTG.'<br>';
            echo 'Headphone => '.$final_headphone.'<br>';
            
            }else{$fm_for_f=$USB_OTG_for_f;}
            $nos=explode('Number of SIMs',$fm_for_f); 
            if(isset($nos[1])){
            $nos_for_f=$nos[1];
            $final_FM=$nos[0];
            echo 'FM => '.$nos[0].'<br>';
            }else{$nos_for_f=$fm_for_f;}

            $s1=explode('SIM 1',$nos_for_f);
            if(isset($s1[1])){
            $nos1_for_f=$s1[1];
            $final_number_of_sim=$s1[0];
            echo 'number of sim  => '.$s1[0].'<br>';            
            }else{$nos1_for_f=$fm_for_f;}

            $SIM_type=explode('SIM Type',$nos1_for_f); 
            if(isset($SIM_type[1])){
            $SIM1_type_for_f=$SIM_type[1];
            $SIM2_type_for_f=$SIM_type[2];            
            }else{$SIM1_type_for_f=$nos1_for_f;
              $SIM2_type_for_f=$nos1_for_f;}


            $GSM_CDMA1=explode('GSM/CDMA',$SIM1_type_for_f); 
            $GSM_CDMA2=explode('GSM/CDMA',$SIM2_type_for_f); 
            if(isset($GSM_CDMA1[1])){

            $GSM_CDMA1_for_f=$GSM_CDMA1[1];
            $GSM_CDMA2_for_f=$GSM_CDMA2[1];
            $final_Sim1_type=$GSM_CDMA1[0];
            $final_Sim2_type=$GSM_CDMA2[0];
            echo "Sim1 type => ".$GSM_CDMA1[0].'<br>';
            echo "Sim2 type => ".$GSM_CDMA2[0].'<br>';            
            }else{$GSM_CDMA1_for_f=$SIM1_type_for_f;
              $GSM_CDMA2_for_f=$SIM2_type_for_f;}

            $tg1=explode('3G',$GSM_CDMA1_for_f); 
            $tg2=explode('3G',$GSM_CDMA2_for_f); 
            if(isset($tg1[1])){
            $tg1_for_f=$tg1[1]; 
            $tg2_for_f=$tg2[1];            
            $final_GSM_CDMA1=$tg1[0];
            $final_GSM_CDMA2=$tg2[0];
            echo "GSM/CDMA1 => ".$tg1[0].'<br>';
            echo "GSM/CDMA2 => ".$tg2[0].'<br>';            
            }else{$tg1_for_f=$SIM1_type_for_f;
              $tg2_for_f=$SIM2_type_for_f;}

            $tg4=explode('4G/ LTE',$tg1_for_f); 
            $tg5=explode('4G/ LTE',$tg2_for_f); 
            if(isset($tg4[1])){
            $tg4_for_f=$tg4[1]; 
            $tg5_for_f=$tg5[1];            
            $final_3G1=$tg4[0];
            $final_3G2=$tg5[0];

            echo "3G1 => ".$tg4[0].'<br>';
            echo "3G2 => ".$tg5[0].'<br>';
            }

           /*for SENSORS*/
           echo '<h1>SENSORS</h1>';
            $Compass_Magnetometer=explode('Compass/ Magnetometer',$nodeList[6]->textContent); 
            if(isset($Compass_Magnetometer[1])){
            $Compass_Magnetometer_for_f=$Compass_Magnetometer[1];            
            }else{$Compass_Magnetometer_for_f=$data;}           

            $Proximity_sensor=explode('Proximity sensor',$Compass_Magnetometer_for_f); 
            if(isset($Proximity_sensor[1])){
            $ps_for_f=$Proximity_sensor[1];
            $final_Compass_Magnetometer=$Proximity_sensor[0];
            echo 'Compass_Magnetometer => '.$Proximity_sensor[0].'<br>';            
            }else{$ps_for_f=$Compass_Magnetometer_for_f;}           
           
            $Accelerometer=explode('Accelerometer',$ps_for_f); 
            if(isset($Accelerometer[1])){
            $Accelerometer_for_f=$Accelerometer[1];
            $final_Proximity_Sensors=$Accelerometer[0];
            echo 'Proximity Sensors => '.$Accelerometer[0].'<br>';            
            }else{$Accelerometer_for_f=$ps_for_f;}           

            $Als=explode('Ambient light sensor',$Accelerometer_for_f); 
            if(isset($Als[1])){
            $Als_for_f=$Als[1];
            $final_Accelerometer=$Als[0];
            echo 'Accelerometer => '.$Als[0].'<br>';            
            }else{$Als_for_f=$Accelerometer_for_f;}           

            $Gyroscope=explode('Gyroscope',$Als_for_f); 
            if(isset($Gyroscope[1])){
            $Gyroscope_for_f=$Gyroscope[1];
            $final_Ambient_light_sensor=$Gyroscope[0];
            echo 'Ambient light sensor => '.$Gyroscope[0].'<br>';            
            }else{$Gyroscope_for_f=$Als_for_f;} 

            $Barometer=explode('Barometer',$Gyroscope_for_f); 
            if(isset($Barometer[1])){
            $Barometer_for_f=$Barometer[1];
            $final_Gyroscope=$Barometer[0];
            echo 'Gyroscope => '.$Barometer[0].'<br>';            
            }else{$Barometer_for_f=$Gyroscope_for_f;}


            $ts=explode('Temperature sensor',$Barometer_for_f); 
            $final_barometer=$ts[0];
            $final_Temperature_sensor=$ts[1];
            echo 'Barometer => '.$ts[0].'<br>';          
            echo 'Temperature sensor => '.$ts[1].'<br>';          

        }else{
             echo "<h1>Os</h1>";
             $os=str_replace('SOFTWARE ','',$nodeList[4]->textContent);            
            $final_os='';
            echo 'OS => '.$final_os.'<br>';
            $final_Skin='';
            echo 'Skin => '.$skin_for_f.'<br>';


          
    /*for Connectivity*/
    echo "<h1>Connectivity</h1>";
    $connectivity=str_replace('CONNECTIVITY ','',$nodeList[4]->textContent);

            $wifi=explode('Wi-Fi standards supported',$connectivity); 
            if(isset($wifi[1])){
            $final_Wi_Fi=str_replace('Wi-Fi','',$wifi[0]);
            echo 'Wi-Fi => '.str_replace('Wi-Fi','',$wifi[0]).'<br>';
            $wifi_for_f=$wifi[1];            
            }else{$wifi_for_f=$data;}           

            $gps=explode('GPS',$wifi_for_f); 
            if(isset($gps[1])){
            $gps_for_f=$gps[1];
            $final_Wi_Fi_standards_supported=$gps[0];
            echo 'Wi-Fi standards supported => '.$gps[0].'<br>';            
            }else{$gps_for_f=$wifi_for_f;}

            $Bluetooth=explode('Bluetooth',$gps_for_f); 
            if(isset($Bluetooth[1])){
            $Bluetooth_for_f=$Bluetooth[1];
            $final_GPS=$Bluetooth[0];
            echo 'GPS => '.$Bluetooth[0].'<br>';            
            }else{$Bluetooth_for_f=$gps_for_f;}
            $NFC=explode('NFC',$Bluetooth_for_f); 
            if(isset($NFC[1])){
            $NFC_for_f=$NFC[1];
            $final_Bluetooth=$NFC[0];
            echo 'Bluetooth => '.$NFC[0].'<br>';            
            }else{$NFC_for_f=$Bluetooth_for_f;}
            $Infrared=explode('Infrared',$NFC_for_f); 
            if(isset($Infrared[1])){
            $Infrared_for_f=$Infrared[1];
            $final_NFC=$Infrared[0];
            echo 'NFC => '.$Infrared[0].'<br>';            
            }else{$Infrared_for_f=$NFC_for_f;}
            $USB_OTG=explode('USB OTG',$Infrared_for_f); 
            if(isset($USB_OTG[1])){
            $USB_OTG_for_f=$USB_OTG[1];
            $final_Infrared=$USB_OTG[0];
            echo 'Infrared => '.$USB_OTG[0].'<br>';
            }else{$USB_OTG_for_f=$Infrared_for_f;}
            $fm=explode('FM',$USB_OTG_for_f);
            if(isset($fm[1])){
            $fm_for_f=$fm[1];
            $final_USB_OTG=$fm[0];

            $final_USB_OTG_dummy=explode('Headphones',$final_USB_OTG);
            //var_dump($final_USB_OTG);
            $final_USB_OTG=$final_USB_OTG_dummy[0];
            $final_headphone=$final_USB_OTG_dummy[1];


            echo 'USB OTG => '.$final_USB_OTG.'<br>';
            echo 'Headphone => '.$final_headphone.'<br>';

            }else{$fm_for_f=$USB_OTG_for_f;}
            $nos=explode('Number of SIMs',$fm_for_f); 
            if(isset($nos[1])){
            $nos_for_f=$nos[1];
            $final_FM=$nos[0];
            echo 'FM => '.$nos[0].'<br>';
            }else{$nos_for_f=$fm_for_f;}

            $s1=explode('SIM 1',$nos_for_f);
            if(isset($s1[1])){
            $nos1_for_f=$s1[1];
            $final_number_of_sim=$s1[0];
            echo 'number of sim  => '.$s1[0].'<br>';            
            }else{$nos1_for_f=$fm_for_f;}

            $SIM_type=explode('SIM Type',$nos1_for_f); 
            if(isset($SIM_type[1])){
            $SIM1_type_for_f=$SIM_type[1];
            $SIM2_type_for_f=$SIM_type[2];            
            }else{$SIM1_type_for_f=$nos1_for_f;
              $SIM2_type_for_f=$nos1_for_f;}


            $GSM_CDMA1=explode('GSM/CDMA',$SIM1_type_for_f); 
            $GSM_CDMA2=explode('GSM/CDMA',$SIM2_type_for_f); 
            if(isset($GSM_CDMA1[1])){

            $GSM_CDMA1_for_f=$GSM_CDMA1[1];
            $GSM_CDMA2_for_f=$GSM_CDMA2[1];
            $final_Sim1_type=$GSM_CDMA1[0];
            $final_Sim2_type=$GSM_CDMA2[0];
            echo "Sim1 type => ".$GSM_CDMA1[0].'<br>';
            echo "Sim2 type => ".$GSM_CDMA2[0].'<br>';            
            }else{$GSM_CDMA1_for_f=$SIM1_type_for_f;
              $GSM_CDMA2_for_f=$SIM2_type_for_f;}

            $tg1=explode('3G',$GSM_CDMA1_for_f); 
            $tg2=explode('3G',$GSM_CDMA2_for_f); 
            if(isset($tg1[1])){
            $tg1_for_f=$tg1[1]; 
            $tg2_for_f=$tg2[1];            
            $final_GSM_CDMA1=$tg1[0];
            $final_GSM_CDMA2=$tg2[0];
            echo "GSM/CDMA1 => ".$tg1[0].'<br>';
            echo "GSM/CDMA2 => ".$tg2[0].'<br>';            
            }else{$tg1_for_f=$SIM1_type_for_f;
              $tg2_for_f=$SIM2_type_for_f;}

            $tg4=explode('4G/ LTE',$tg1_for_f); 
            $tg5=explode('4G/ LTE',$tg2_for_f); 
            if(isset($tg4[1])){
            $tg4_for_f=$tg4[1]; 
            $tg5_for_f=$tg5[1];            
            $final_3G1=$tg4[0];
            $final_3G2=$tg5[0];

            echo "3G1 => ".$tg4[0].'<br>';
            echo "3G2 => ".$tg5[0].'<br>';
            }

           /*for SENSORS*/
           echo '<h1>SENSORS</h1>';

            $Compass_Magnetometer=explode('Compass/ Magnetometer',$nodeList[5]->textContent); 
            if(isset($Compass_Magnetometer[1])){
            $Compass_Magnetometer_for_f=$Compass_Magnetometer[1];            
            }else{$Compass_Magnetometer_for_f=$data;}           

            $Proximity_sensor=explode('Proximity sensor',$Compass_Magnetometer_for_f); 
            if(isset($Proximity_sensor[1])){
            $ps_for_f=$Proximity_sensor[1];
            $final_Compass_Magnetometer=$Proximity_sensor[0];
            echo 'Compass_Magnetometer => '.$Proximity_sensor[0].'<br>';            
            }else{$ps_for_f=$Compass_Magnetometer_for_f;}           
           
            $Accelerometer=explode('Accelerometer',$ps_for_f); 
            if(isset($Accelerometer[1])){
            $Accelerometer_for_f=$Accelerometer[1];
            $final_Proximity_Sensors=$Accelerometer[0];
            echo 'Proximity Sensors => '.$Accelerometer[0].'<br>';            
            }else{$Accelerometer_for_f=$ps_for_f;}           

            $Als=explode('Ambient light sensor',$Accelerometer_for_f); 
            if(isset($Als[1])){
            $Als_for_f=$Als[1];
            $final_Accelerometer=$Als[0];
            echo 'Accelerometer => '.$Als[0].'<br>';            
            }else{$Als_for_f=$Accelerometer_for_f;}           

            $Gyroscope=explode('Gyroscope',$Als_for_f); 
            if(isset($Gyroscope[1])){
            $Gyroscope_for_f=$Gyroscope[1];
            $final_Ambient_light_sensor=$Gyroscope[0];
            echo 'Ambient light sensor => '.$Gyroscope[0].'<br>';            
            }else{$Gyroscope_for_f=$Als_for_f;} 

            $Barometer=explode('Barometer',$Gyroscope_for_f); 
            if(isset($Barometer[1])){
            $Barometer_for_f=$Barometer[1];
            $final_Gyroscope=$Barometer[0];
            echo 'Gyroscope => '.$Barometer[0].'<br>';            
            }else{$Barometer_for_f=$Gyroscope_for_f;}

             $ts=explode('Temperature sensor',$Barometer_for_f); 
            $final_barometer=$ts[0];
            $final_Temperature_sensor=$ts[1];
            echo 'Barometer => '.$ts[0].'<br>';          
            echo 'Temperature sensor => '.$ts[1].'<br>'; /*

            $ts=explode('Temperature sensor',$Barometer_for_f); 
            $final_Temperature_sensor=$ts[0];
            echo 'Temperature sensor => '.$ts[0].'<br>'; */         

        }
//var_dump($ts_for_f);
//var_dump($SIM_type);


        if (strlen($final_description)>5) {
          echo 'YEs';
          # code...
        
$con=mysqli_connect("localhost","root","","avatarde");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  else{
  //  echo "connected";
  }
$value=str_replace('-',' ',$brand_name);
$value=trim(ucwords($value));
$sql="SELECT * FROM brands WHERE name='".$value."'";
$id = '';
$city_price ='';
$value=str_replace('-',' ',$value);
$sql2 ="INSERT INTO brands (name)
VALUES ('$value')";

if ($con->query($sql2) === TRUE) {
    echo "<br><h1 style='color:green'>New Brand created successfully!!!</h1>";
} else {
    echo "<br><h1 style='color:red'>brand name already in table</h1>";
    echo "Error: " . $sql2 . "<br>" . $con->error;
}

if ($result=mysqli_query($con,$sql))
  {



/*WRITE INSERT QUERY */

   // var_dump($result);
 // Fetch one and one row

  while ($row=mysqli_fetch_row($result))
    {       //echo $value.'<br>';
    if($value===$row[1]){

        $id=$row[0];

        //$city_price =trim(str_replace(',','',$_SESSION['price']));
$sql="INSERT INTO `mobile_models` (`brand_id`, 
`name`, 
`about`,
 `release_date`,
 `screen_factor`,
 `dimensions_mm`,
 `weigh_g`,
 `battery_capacity_mAh`,
 `removable_battery`,
 `colors`,
 `SAR_value`,
  `Screen_size_inches`,
  `Touchscreen`,
  `Resolution`,
  `PPI`,
  `Processor`,`Processor_make`,`RAM`,`Internal_storage`,`Expandable_storage`,`Expandable_storage_type`,`Expandable_storage_up_to_GB`,`Rear_camera`,`Flash`,
  `Front_camera`,`Operating_System`,`os_skin`,`Wi_Fi`,`Wi_Fi_standards_supported`,`GPS`,`Bluetooth`,`NFC`,`Infrared`,`USB_OTG`,`Headphones`, `FM`,`Number_of_SIMs`,
   `SIM_Type`, `GSM_CDMA`, `tG`, `fG_LTE`,`SIM_Type2`, `GSM_CDMA2`, `tG2`, `fG_LTE2`, `Compass_Magnetometer`, `Proximity_sensor`, `Accelerometer`, `Ambient_light_sensor`, `Gyroscope`, `Barometer`, `Temperature_sensor`, `images`, `video`, `amazon_price`, `flipkart_price`, `snapdeal_price`, `isLive`) VALUES             
 ($id, '$model_name','$final_description','$final_Release_date', '$final_form_factor', '$final_Dimensions_mm', '$final_Weight_g', '$final_Battery_capacity_mAh', '$final_Removable_battery', '$final_colors','$SAR_value', '$final_Screen_size_inches', '$final_Touchscreen', '$final_resolution', '$final_Pixels_per_inch_PPI','$fonal_processor','$final_Processor_brand', '$final_ram', '$final_Internal_storage', '$final_Expandable_storage', '$final_Expandable_storage_type', '$final_Expandable_storage_up_to_GB', '$final_Rear_camera', '$final_Flash', '$final_Front_camera', '$final_os', '$final_Skin', '$final_Wi_Fi', '$final_Wi_Fi_standards_supported', '$final_GPS','$final_Bluetooth', '$final_NFC', '$final_Infrared','$final_USB_OTG','$final_headphone','$final_FM', '$final_number_of_sim', '$final_Sim1_type', '$final_GSM_CDMA1','$final_3G1','', '$final_Sim2_type', '$final_GSM_CDMA2', '$final_3G2', '', '$final_Compass_Magnetometer', '$final_Proximity_Sensors', '$final_Accelerometer', '$final_Ambient_light_sensor', '$final_Gyroscope', '$final_barometer', '$final_Temperature_sensor', '', '', '', '', '', '1')";
if(mysqli_query($con,$sql)){
    echo "<h4 style='color:green'>Record inserted successfully</h4>";
     }
     else{
    echo "<div style='color:red'><h1>error</h1>";
      echo "</div>";  
      echo "Error: " . $sql . "<br>" . $con->error;

     }
    }
else{
      echo "";
    echo "<div style='color:red'><h1>Erroe</h1>";
      echo "</div>";
      echo "Error: " . $sql . "<br>" . $con->error;
}

   // print_r($row);
    }
  // Free result set
}


}

            


           
            
            //print_r($color_name);
      
                    //}

                  //  return $output;

/*
                      $price.'<br>';
        $date.'<br>';    
        $releasedate.'<br>';*/
        





    }
$data=curl('gadgets.ndtv.com/-'.$_REQUEST['id'],'');
/*sleep(1);*/
echo "<hr>";



    

   // print_r($data);
$data_id=$_REQUEST['id']+1;
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body id="bdy" >
<!--  <form action="" method="GET">
<input type="text" name="brand" value="<?php echo $brand_name; ?>" placeholder=" Brand name">
<input type="text" name="model" value="<?php echo $model_name; ?>" placeholder=" Model name">
<input type="text" name="city" value="New-Delhi" placeholder=" city name">
<input type="text" name="varient" value="<?php echo $varient_name; ?>" placeholder=" Variat name">

<input type="submit" name="submit" value="change">
</select>
</form>-->
<script>
var id="<?php echo $data_id?>";
//alert(next_city); 
//upto 4120-4130
if(id.length>=0 && id<=4150){
  setTimeout(function(){
  window.location.href = "http://localhost/moviepazes_pro/avatarde.php?id="+id;
},100);}else{
    window.location.href = "http://localhost/moviepazes_pro/avatarde2.php";
  }
/*setTimeout(function () { location.reload(1); }, 5000);*/
  /*http://localhost/car_price/data.php?brand=audi-cars&model=a3&city=New-Delhi&varient=35-tdi-premium-plus*/
</script>
</body>
</html>